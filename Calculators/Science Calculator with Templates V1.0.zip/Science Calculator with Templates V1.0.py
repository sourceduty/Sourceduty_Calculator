# Science Calculator with Templates V1.0
# Copyright (C) 2024, Sourceduty - All Rights Reserved.

import tkinter as tk
from tkinter import Menu, Text, messagebox
import math

class ScienceCalculator(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Science Calculator")
        self.geometry("800x600")
        self.resizable(False, False)
        self.expression = ""
        
        self.create_widgets()
    
    def create_widgets(self):
        # Display for calculation
        self.display = tk.Entry(self, font=("Arial", 32), borderwidth=2, relief="solid", justify="right")
        self.display.grid(row=0, column=0, columnspan=4, padx=10, pady=20, ipadx=8, ipady=20)

        # Buttons layout
        buttons = [
            ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('/', 1, 3),
            ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('*', 2, 3),
            ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('-', 3, 3),
            ('0', 4, 0), ('.', 4, 1), ('+', 4, 2), ('=', 4, 3),
        ]
        
        for (text, row, col) in buttons:
            tk.Button(self, text=text, font=("Arial", 24), width=5, height=2, command=lambda t=text: self.on_button_click(t)).grid(row=row, column=col, sticky="nsew", padx=5, pady=5)
        
        # Additional buttons
        tk.Button(self, text="C", font=("Arial", 24), width=11, height=2, command=self.clear_display).grid(row=5, column=0, columnspan=2, sticky="nsew", padx=5, pady=5)
        
        # Grid configuration for responsiveness
        for i in range(6):
            self.grid_rowconfigure(i, weight=1)
        for i in range(4):
            self.grid_columnconfigure(i, weight=1)
        
        # Menu Integration
        self.create_menu()

        # Template Manager Integration
        self.template_manager = TemplateManager(self)
        self.template_manager.create_template_widgets()

    def create_menu(self):
        # Create the main menu
        menu_bar = Menu(self)

        # Physics Menu
        physics_menu = Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label="Physics", menu=physics_menu)
        physics_menu.add_command(label="Speed Calculation", command=lambda: self.template_manager.on_template_select("Speed Calculation"))
        physics_menu.add_command(label="Acceleration", command=lambda: self.template_manager.on_template_select("Acceleration"))
        physics_menu.add_command(label="Force (F=ma)", command=lambda: self.template_manager.on_template_select("Force (F=ma)"))
        physics_menu.add_command(label="Kinetic Energy", command=lambda: self.template_manager.on_template_select("Kinetic Energy"))
        physics_menu.add_command(label="Potential Energy", command=lambda: self.template_manager.on_template_select("Potential Energy"))
        physics_menu.add_command(label="Ohm's Law (V=IR)", command=lambda: self.template_manager.on_template_select("Ohm's Law (V=IR)"))
        physics_menu.add_command(label="Power (P=IV)", command=lambda: self.template_manager.on_template_select("Power (P=IV)"))
        physics_menu.add_command(label="Work Done", command=lambda: self.template_manager.on_template_select("Work Done"))

        # Chemistry Menu
        chemistry_menu = Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label="Chemistry", menu=chemistry_menu)
        chemistry_menu.add_command(label="Molar Mass", command=lambda: self.template_manager.on_template_select("Molar Mass"))
        chemistry_menu.add_command(label="Concentration (Molarity)", command=lambda: self.template_manager.on_template_select("Concentration (Molarity)"))
        chemistry_menu.add_command(label="Dilution Calculation", command=lambda: self.template_manager.on_template_select("Dilution Calculation"))
        chemistry_menu.add_command(label="Ideal Gas Law", command=lambda: self.template_manager.on_template_select("Ideal Gas Law"))
        chemistry_menu.add_command(label="Stoichiometry", command=lambda: self.template_manager.on_template_select("Stoichiometry"))
        chemistry_menu.add_command(label="pH Calculation", command=lambda: self.template_manager.on_template_select("pH Calculation"))
        chemistry_menu.add_command(label="Heat Transfer (q=mcΔT)", command=lambda: self.template_manager.on_template_select("Heat Transfer (q=mcΔT)"))

        # Biology Menu
        biology_menu = Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label="Biology", menu=biology_menu)
        biology_menu.add_command(label="Punnett Square", command=lambda: self.template_manager.on_template_select("Punnett Square"))
        biology_menu.add_command(label="Population Growth", command=lambda: self.template_manager.on_template_select("Population Growth"))
        biology_menu.add_command(label="Photosynthesis Equation", command=lambda: self.template_manager.on_template_select("Photosynthesis Equation"))
        biology_menu.add_command(label="Cell Division Rate", command=lambda: self.template_manager.on_template_select("Cell Division Rate"))
        biology_menu.add_command(label="Genotype Probability", command=lambda: self.template_manager.on_template_select("Genotype Probability"))
        biology_menu.add_command(label="Energy Flow in Ecosystems", command=lambda: self.template_manager.on_template_select("Energy Flow in Ecosystems"))

        # Environmental Science Menu
        environmental_menu = Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label="Environmental Science", menu=environmental_menu)
        environmental_menu.add_command(label="Carbon Footprint", command=lambda: self.template_manager.on_template_select("Carbon Footprint"))
        environmental_menu.add_command(label="Water Footprint", command=lambda: self.template_manager.on_template_select("Water Footprint"))
        environmental_menu.add_command(label="Ecological Footprint", command=lambda: self.template_manager.on_template_select("Ecological Footprint"))
        environmental_menu.add_command(label="Population Density", command=lambda: self.template_manager.on_template_select("Population Density"))

        # Astronomy Menu
        astronomy_menu = Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label="Astronomy", menu=astronomy_menu)
        astronomy_menu.add_command(label="Kepler's Third Law", command=lambda: self.template_manager.on_template_select("Kepler's Third Law"))
        astronomy_menu.add_command(label="Escape Velocity", command=lambda: self.template_manager.on_template_select("Escape Velocity"))
        astronomy_menu.add_command(label="Luminosity of a Star", command=lambda: self.template_manager.on_template_select("Luminosity of a Star"))
        astronomy_menu.add_command(label="Distance Modulus", command=lambda: self.template_manager.on_template_select("Distance Modulus"))

        # Attach the menu to the window
        self.config(menu=menu_bar)

    def on_button_click(self, text):
        if text == "=":
            try:
                self.expression = str(eval(self.expression))
                self.update_display()
            except Exception as e:
                self.display.insert(tk.END, " Error")
                self.expression = ""
        else:
            self.expression += text
            self.update_display()
    
    def clear_display(self):
        self.expression = ""
        self.update_display()
    
    def update_display(self):
        self.display.delete(0, tk.END)
        self.display.insert(tk.END, self.expression)

class TemplateManager:
    def __init__(self, parent):
        self.parent = parent
        self.templates = {
            # Physics Templates
            "Speed Calculation": "distance / time",
            "Acceleration": "(final_velocity - initial_velocity) / time",
            "Force (F=ma)": "mass * acceleration",
            "Kinetic Energy": "0.5 * mass * velocity ** 2",
            "Potential Energy": "mass * gravity * height",
            "Ohm's Law (V=IR)": "current * resistance",
            "Power (P=IV)": "current * voltage",
            "Work Done": "force * distance",

            # Chemistry Templates
            "Molar Mass": "self.calculate_molar_mass(compound)",
            "Concentration (Molarity)": "moles_of_solute / liters_of_solution",
            "Dilution Calculation": "C1 * V1 == C2 * V2",
            "Ideal Gas Law": "(pressure * volume) / (R * temperature)",
            "Stoichiometry": "self.stoichiometry_calculation(balance_equation, given_quantity)",
            "pH Calculation": "-math.log10(hydrogen_ion_concentration)",
            "Heat Transfer (q=mcΔT)": "mass * specific_heat * temperature_change",

            # Biology Templates
            "Punnett Square": "self.punnett_square(allele1, allele2)",
            "Population Growth": "initial_population * math.exp(growth_rate * time)",
            "Photosynthesis Equation": "6CO2 + 6H2O -> C6H12O6 + 6O2",
            "Cell Division Rate": "initial_cells * 2 ** (time / generation_time)",
            "Genotype Probability": "self.genotype_probability(allele1, allele2)",
            "Energy Flow in Ecosystems": "self.energy_flow(energy_input, trophic_levels)",

            # Environmental Science Templates
            "Carbon Footprint": "self.calculate_carbon_footprint(activity, duration)",
            "Water Footprint": "self.calculate_water_footprint(activity, usage)",
            "Ecological Footprint": "self.calculate_ecological_footprint(area, population)",
            "Population Density": "population / area",

            # Astronomy Templates
            "Kepler's Third Law": "math.sqrt((orbital_period ** 2) / (semi_major_axis ** 3))",
            "Escape Velocity": "math.sqrt(2 * gravity_constant * mass / radius)",
            "Luminosity of a Star": "4 * math.pi * radius ** 2 * stefan_boltzmann_constant * temperature ** 4",
            "Distance Modulus": "5 * math.log10(distance / 10)"
        }
        self.selected_template = tk.StringVar(self.parent)
    
    def create_template_widgets(self):
        # Template selection Drop-down menu
        self.template_frame = tk.Frame(self.parent)
        self.template_frame.grid(row=0, column=4, rowspan=6, padx=20, pady=20, sticky="nswe")

        tk.Label(self.template_frame, text="Templates", font=("Arial", 18)).pack(anchor='w')

        # Notepad and Entry for Templates
        self.notepad = Text(self.template_frame, font=("Arial", 14), height=15, width=35, wrap="word", bg="white", fg="black", borderwidth=2, relief="solid")
        self.notepad.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        self.entry_bar = tk.Entry(self.template_frame, font=("Arial", 18), borderwidth=2, relief="solid")
        self.entry_bar.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Button(self.template_frame, text="Enter", font=("Arial", 18), command=self.calculate_template).pack(pady=10)

    def on_template_select(self, selected_template):
        if selected_template:
            template_expression = self.templates[selected_template]
            self.display_template(template_expression)
    
    def display_template(self, expression):
        self.notepad.delete(1.0, tk.END)
        self.notepad.insert(tk.END, f"Template: {expression}\n")
        self.entry_bar.delete(0, tk.END)
        self.entry_bar.insert(0, "Enter values here separated by commas (e.g., 5, 10)")

    def calculate_template(self):
        selected_template = self.selected_template.get()
        if selected_template and selected_template != "Select Template":
            template_expression = self.templates[selected_template]
            try:
                # Handle special cases for science calculations
                if selected_template in ["Molar Mass", "Stoichiometry", "Punnett Square", "Genotype Probability", "Energy Flow in Ecosystems"]:
                    inputs = self.entry_bar.get().split(',')
                    method_to_call = getattr(self, selected_template.lower().replace(" ", "_"))
                    result = method_to_call(*inputs)
                else:
                    input_values = list(map(float, self.entry_bar.get().split(',')))
                    result = eval(template_expression, {}, dict(zip(self.templates.keys(), input_values)))
                messagebox.showinfo("Result", f"Result: {result}")
            except Exception as e:
                messagebox.showerror("Error", f"Error in calculation: {e}")
        else:
            messagebox.showerror("Error", "Please select a template.")
    
    # Science-specific methods for calculation
    def calculate_molar_mass(self, compound):
        # Placeholder method for calculating molar mass of a compound
        molar_mass = {
            "H2O": 18.015,
            "CO2": 44.01,
            # Add more compounds as needed
        }
        return molar_mass.get(compound, "Compound not found")

    def stoichiometry_calculation(self, balance_equation, given_quantity):
        # Placeholder method for stoichiometry calculation
        return f"Stoichiometry result for {balance_equation} with {given_quantity}g"

    def punnett_square(self, allele1, allele2):
        # Placeholder method for generating a Punnett Square
        return f"Punnett Square for {allele1} and {allele2}"

    def genotype_probability(self, allele1, allele2):
        # Placeholder method for calculating genotype probability
        return f"Genotype probability for {allele1} and {allele2}"

    def energy_flow(self, energy_input, trophic_levels):
        # Placeholder method for calculating energy flow in ecosystems
        return f"Energy flow through {trophic_levels} levels with input {energy_input}"

    def calculate_carbon_footprint(self, activity, duration):
        # Placeholder method for calculating carbon footprint
        return f"Carbon footprint for {activity} over {duration} hours"

    def calculate_water_footprint(self, activity, usage):
        # Placeholder method for calculating water footprint
        return f"Water footprint for {activity} with usage {usage} liters"

    def calculate_ecological_footprint(self, area, population):
        # Placeholder method for calculating ecological footprint
        return f"Ecological footprint for area {area} and population {population}"

if __name__ == "__main__":
    app = ScienceCalculator()
    app.mainloop()
