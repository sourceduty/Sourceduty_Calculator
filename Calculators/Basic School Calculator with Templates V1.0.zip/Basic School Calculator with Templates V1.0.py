# Basic School Calculator with Templates V1.0
# Copyright (C) 2024, Sourceduty - All Rights Reserved.

import tkinter as tk
from tkinter import Menu, Text, messagebox
import math

class SchoolCalculator(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("School Calculator")
        self.geometry("800x600")
        self.resizable(False, False)
        self.expression = ""
        
        self.create_widgets()
    
    def create_widgets(self):
        # Display for calculation
        self.display = tk.Entry(self, font=("Arial", 32), borderwidth=2, relief="solid", justify="right")
        self.display.grid(row=0, column=0, columnspan=4, padx=10, pady=20, ipadx=8, ipady=20)

        # Buttons layout
        buttons = [
            ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('/', 1, 3),
            ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('*', 2, 3),
            ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('-', 3, 3),
            ('0', 4, 0), ('.', 4, 1), ('+', 4, 2), ('=', 4, 3),
        ]
        
        for (text, row, col) in buttons:
            tk.Button(self, text=text, font=("Arial", 24), width=5, height=2, command=lambda t=text: self.on_button_click(t)).grid(row=row, column=col, sticky="nsew", padx=5, pady=5)
        
        # Additional buttons
        tk.Button(self, text="C", font=("Arial", 24), width=11, height=2, command=self.clear_display).grid(row=5, column=0, columnspan=2, sticky="nsew", padx=5, pady=5)
        
        # Grid configuration for responsiveness
        for i in range(6):
            self.grid_rowconfigure(i, weight=1)
        for i in range(4):
            self.grid_columnconfigure(i, weight=1)
        
        # Menu Integration
        self.create_menu()

        # Template Manager Integration
        self.template_manager = TemplateManager(self)
        self.template_manager.create_template_widgets()

    def create_menu(self):
        # Create the main menu
        menu_bar = Menu(self)

        # Create "Algebra" menu
        algebra_menu = Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label="Algebra", menu=algebra_menu)
        algebra_menu.add_command(label="Quadratic Equation", command=lambda: self.template_manager.on_template_select("Quadratic Equation"))
        algebra_menu.add_command(label="Slope of a Line", command=lambda: self.template_manager.on_template_select("Slope of a Line"))
        algebra_menu.add_command(label="Solve Linear Equation", command=lambda: self.template_manager.on_template_select("Solve Linear Equation"))
        algebra_menu.add_command(label="Factoring Quadratic Equation", command=lambda: self.template_manager.on_template_select("Factoring Quadratic Equation"))
        algebra_menu.add_command(label="Absolute Value", command=lambda: self.template_manager.on_template_select("Absolute Value"))
        algebra_menu.add_command(label="Exponentiation", command=lambda: self.template_manager.on_template_select("Exponentiation"))

        # Create "Geometry" menu
        geometry_menu = Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label="Geometry", menu=geometry_menu)
        geometry_menu.add_command(label="Area of a Circle", command=lambda: self.template_manager.on_template_select("Area of a Circle"))
        geometry_menu.add_command(label="Perimeter of a Rectangle", command=lambda: self.template_manager.on_template_select("Perimeter of a Rectangle"))
        geometry_menu.add_command(label="Area of a Triangle", command=lambda: self.template_manager.on_template_select("Area of a Triangle"))
        geometry_menu.add_command(label="Volume of a Cylinder", command=lambda: self.template_manager.on_template_select("Volume of a Cylinder"))
        geometry_menu.add_command(label="Surface Area of a Sphere", command=lambda: self.template_manager.on_template_select("Surface Area of a Sphere"))
        geometry_menu.add_command(label="Pythagorean Theorem", command=lambda: self.template_manager.on_template_select("Pythagorean Theorem"))

        # Create "Trigonometry" menu
        trigonometry_menu = Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label="Trigonometry", menu=trigonometry_menu)
        trigonometry_menu.add_command(label="Sine", command=lambda: self.template_manager.on_template_select("Sine"))
        trigonometry_menu.add_command(label="Cosine", command=lambda: self.template_manager.on_template_select("Cosine"))
        trigonometry_menu.add_command(label="Tangent", command=lambda: self.template_manager.on_template_select("Tangent"))
        trigonometry_menu.add_command(label="Law of Sines", command=lambda: self.template_manager.on_template_select("Law of Sines"))
        trigonometry_menu.add_command(label="Law of Cosines", command=lambda: self.template_manager.on_template_select("Law of Cosines"))
        trigonometry_menu.add_command(label="Angle Conversion", command=lambda: self.template_manager.on_template_select("Angle Conversion"))

        # Attach the menu to the window
        self.config(menu=menu_bar)

    def on_button_click(self, text):
        if text == "=":
            try:
                self.expression = str(eval(self.expression))
                self.update_display()
            except Exception as e:
                self.display.insert(tk.END, " Error")
                self.expression = ""
        else:
            self.expression += text
            self.update_display()
    
    def clear_display(self):
        self.expression = ""
        self.update_display()
    
    def update_display(self):
        self.display.delete(0, tk.END)
        self.display.insert(tk.END, self.expression)

class TemplateManager:
    def __init__(self, parent):
        self.parent = parent
        self.templates = {
            "Quadratic Equation": "self.solve_quadratic(a, b, c)",
            "Slope of a Line": "self.calculate_slope(x1, y1, x2, y2)",
            "Solve Linear Equation": "self.solve_linear(a, b, c)",
            "Factoring Quadratic Equation": "self.factor_quadratic(a, b, c)",
            "Absolute Value": "abs(number)",
            "Exponentiation": "base ** exponent",
            "Area of a Circle": "math.pi * radius ** 2",
            "Perimeter of a Rectangle": "2 * (length + width)",
            "Area of a Triangle": "0.5 * base * height",
            "Volume of a Cylinder": "math.pi * radius ** 2 * height",
            "Surface Area of a Sphere": "4 * math.pi * radius ** 2",
            "Pythagorean Theorem": "math.sqrt(a ** 2 + b ** 2)",
            "Sine": "math.sin(math.radians(angle))",
            "Cosine": "math.cos(math.radians(angle))",
            "Tangent": "math.tan(math.radians(angle))",
            "Law of Sines": "a / math.sin(math.radians(A)) == b / math.sin(math.radians(B)) == c / math.sin(math.radians(C))",
            "Law of Cosines": "math.sqrt(a ** 2 + b ** 2 - 2 * a * b * math.cos(math.radians(C)))",
            "Angle Conversion": "math.degrees(angle) if angle is in radians else math.radians(angle)"
        }
        self.selected_template = tk.StringVar(self.parent)
    
    def create_template_widgets(self):
        # Template selection Drop-down menu
        self.template_frame = tk.Frame(self.parent)
        self.template_frame.grid(row=0, column=4, rowspan=6, padx=20, pady=20, sticky="nswe")

        tk.Label(self.template_frame, text="Templates", font=("Arial", 18)).pack(anchor='w')

        # Notepad and Entry for Templates
        self.notepad = Text(self.template_frame, font=("Arial", 14), height=15, width=35, wrap="word", bg="white", fg="black", borderwidth=2, relief="solid")
        self.notepad.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        self.entry_bar = tk.Entry(self.template_frame, font=("Arial", 18), borderwidth=2, relief="solid")
        self.entry_bar.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Button(self.template_frame, text="Enter", font=("Arial", 18), command=self.calculate_template).pack(pady=10)

    def on_template_select(self, selected_template):
        if selected_template:
            template_expression = self.templates[selected_template]
            self.display_template(template_expression)
    
    def display_template(self, expression):
        self.notepad.delete(1.0, tk.END)
        self.notepad.insert(tk.END, f"Template: {expression}\n")
        self.entry_bar.delete(0, tk.END)
        self.entry_bar.insert(0, "Enter values here separated by commas (e.g., 1, -3, 2)")

    def calculate_template(self):
        selected_template = self.selected_template.get()
        if selected_template and selected_template != "Select Template":
            template_expression = self.templates[selected_template]
            try:
                # Handle special cases for high school calculations
                if selected_template == "Quadratic Equation":
                    inputs = list(map(float, self.entry_bar.get().split(',')))
                    result = self.solve_quadratic(*inputs)
                elif selected_template == "Slope of a Line":
                    inputs = list(map(float, self.entry_bar.get().split(',')))
                    result = self.calculate_slope(*inputs)
                elif selected_template == "Solve Linear Equation":
                    inputs = list(map(float, self.entry_bar.get().split(',')))
                    result = self.solve_linear(*inputs)
                elif selected_template == "Factoring Quadratic Equation":
                    inputs = list(map(float, self.entry_bar.get().split(',')))
                    result = self.factor_quadratic(*inputs)
                else:
                    input_values = list(map(float, self.entry_bar.get().split(',')))
                    result = eval(template_expression, {}, dict(zip(self.templates.keys(), input_values)))
                messagebox.showinfo("Result", f"Result: {result}")
            except Exception as e:
                messagebox.showerror("Error", f"Error in calculation: {e}")
        else:
            messagebox.showerror("Error", "Please select a template.")
    
    # High school-specific methods
    def solve_quadratic(self, a, b, c):
        discriminant = b**2 - 4*a*c
        if discriminant > 0:
            root1 = (-b + math.sqrt(discriminant)) / (2 * a)
            root2 = (-b - math.sqrt(discriminant)) / (2 * a)
            return root1, root2
        elif discriminant == 0:
            root = -b / (2 * a)
            return root
        else:
            return "No real roots"

    def calculate_slope(self, x1, y1, x2, y2):
        if x1 == x2:
            return "Slope is undefined (vertical line)"
        else:
            return (y2 - y1) / (x2 - x1)

    def solve_linear(self, a, b, c):
        if a == 0:
            return "Not a valid equation"
        else:
            return (c - b) / a

    def factor_quadratic(self, a, b, c):
        discriminant = b**2 - 4*a*c
        if discriminant >= 0:
            root1 = (-b + math.sqrt(discriminant)) / (2 * a)
            root2 = (-b - math.sqrt(discriminant)) / (2 * a)
            return (root1, root2)
        else:
            return "Cannot factor: no real roots"

if __name__ == "__main__":
    app = SchoolCalculator()
    app.mainloop()

