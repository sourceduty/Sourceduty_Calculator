# Money Calculator with Templates V1.0
# Copyright (C) 2024, Sourceduty - All Rights Reserved.

import tkinter as tk
from tkinter import Menu, Text, messagebox
import time
import math
import requests

class MoneyCalculator(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Money Calculator")
        self.geometry("900x600")
        self.resizable(False, False)
        self.expression = ""
        self.currency_rates = self.get_currency_rates()
        
        self.create_widgets()
    
    def create_widgets(self):
        # Display for calculation
        self.display = tk.Entry(self, font=("Arial", 32), borderwidth=2, relief="solid", justify="right")
        self.display.grid(row=0, column=0, columnspan=4, padx=10, pady=20, ipadx=8, ipady=20)

        # Buttons layout
        buttons = [
            ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('/', 1, 3),
            ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('*', 2, 3),
            ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('-', 3, 3),
            ('0', 4, 0), ('.', 4, 1), ('+', 4, 2), ('=', 4, 3),
        ]
        
        for (text, row, col) in buttons:
            tk.Button(self, text=text, font=("Arial", 24), width=5, height=2, command=lambda t=text: self.on_button_click(t)).grid(row=row, column=col, sticky="nsew", padx=5, pady=5)
        
        # Additional buttons
        tk.Button(self, text="C", font=("Arial", 24), width=11, height=2, command=self.clear_display).grid(row=5, column=0, columnspan=2, sticky="nsew", padx=5, pady=5)
        
        # Grid configuration for responsiveness
        for i in range(6):
            self.grid_rowconfigure(i, weight=1)
        for i in range(4):
            self.grid_columnconfigure(i, weight=1)
        
        # Menu Integration
        self.create_menu()

        # Template Manager Integration
        self.template_manager = TemplateManager(self, self.currency_rates)
        self.template_manager.create_template_widgets()

    def create_menu(self):
        # Create the main menu
        menu_bar = Menu(self)

        # Create "Financial Calculations" menu
        financial_menu = Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label="Financial Calculations", menu=financial_menu)

        # Submenus under "Financial Calculations"
        interest_menu = Menu(financial_menu, tearoff=0)
        financial_menu.add_cascade(label="Interest Calculations", menu=interest_menu)
        interest_menu.add_command(label="Simple Interest", command=lambda: self.template_manager.on_template_select("Simple Interest"))
        interest_menu.add_command(label="Compound Interest", command=lambda: self.template_manager.on_template_select("Compound Interest"))

        loan_menu = Menu(financial_menu, tearoff=0)
        financial_menu.add_cascade(label="Loan and Mortgage", menu=loan_menu)
        loan_menu.add_command(label="Loan Amortization", command=lambda: self.template_manager.on_template_select("Loan Amortization"))
        loan_menu.add_command(label="Monthly Mortgage Payment", command=lambda: self.template_manager.on_template_select("Monthly Mortgage Payment"))

        additional_menu = Menu(financial_menu, tearoff=0)
        financial_menu.add_cascade(label="Additional Calculations", menu=additional_menu)
        additional_menu.add_command(label="Debt-to-Income Ratio", command=lambda: self.template_manager.on_template_select("Debt-to-Income Ratio"))
        additional_menu.add_command(label="Inflation-Adjusted Return", command=lambda: self.template_manager.on_template_select("Inflation-Adjusted Return"))
        additional_menu.add_command(label="Bond Pricing", command=lambda: self.template_manager.on_template_select("Bond Pricing"))
        additional_menu.add_command(label="Dividend Yield", command=lambda: self.template_manager.on_template_select("Dividend Yield"))

        # Create "Currency Conversions" menu
        currency_menu = Menu(menu_bar, tearoff=0)
        menu_bar.add_cascade(label="Currency Conversions", menu=currency_menu)

        # Submenus under "Currency Conversions"
        convert_menu = Menu(currency_menu, tearoff=0)
        currency_menu.add_cascade(label="Convert Currencies", menu=convert_menu)
        for currency in self.currency_rates.keys():
            convert_menu.add_command(label=f"Convert {currency} to Others", command=lambda c=currency: self.template_manager.convert_currency(c))

        # Attach the menu to the window
        self.config(menu=menu_bar)

    def on_button_click(self, text):
        if text == "=":
            try:
                self.expression = str(eval(self.expression))
                self.update_display()
            except Exception as e:
                self.display.insert(tk.END, " Error")
                self.expression = ""
        else:
            self.expression += text
            self.update_display()
    
    def clear_display(self):
        self.expression = ""
        self.update_display()
    
    def update_display(self):
        self.display.delete(0, tk.END)
        self.display.insert(tk.END, self.expression)
    
    def get_currency_rates(self):
        # Fetch currency exchange rates from an API (Placeholder API)
        try:
            response = requests.get("https://api.exchangerate-api.com/v4/latest/USD")
            data = response.json()
            return data['rates']
        except Exception as e:
            print(f"Error fetching currency rates: {e}")
            return {}

class TemplateManager:
    def __init__(self, parent, currency_rates):
        self.parent = parent
        self.currency_rates = currency_rates
        self.templates = {
            "Currency Conversion": "self.currency_conversion(amount, from_currency, to_currency)",
            "Simple Interest": "(principal * rate * time) / 100",
            "Compound Interest": "principal * ((1 + rate / 100) ** time) - principal",
            "Loan Amortization": "self.loan_amortization(principal, rate, time)",
            "Savings Growth": "principal * ((1 + rate / 100) ** time)",
            "Monthly Mortgage Payment": "self.mortgage_payment(principal, rate, time)",
            "Future Value of Investment": "principal * ((1 + rate / 100) ** time)",
            "Discounted Cash Flow (DCF)": "cash_flow / ((1 + discount_rate) ** period)",
            "Retirement Savings Estimate": "self.retirement_savings(current_savings, annual_contribution, years, rate)",
            "Break-Even Analysis": "fixed_costs / (selling_price - variable_costs_per_unit)",
            "Profit Margin": "((revenue - cost) / revenue) * 100",
            "Return on Investment (ROI)": "((final_value - initial_investment) / initial_investment) * 100",
            "Net Present Value (NPV)": "sum([cash_flow / ((1 + discount_rate) ** period) for period, cash_flow in enumerate(cash_flows, 1)])",
            "Payback Period": "initial_investment / annual_cash_flow",
            "APR Calculation": "self.apr(principal, interest, time)",
            "Debt-to-Income Ratio": "(total_debt_payments / gross_income) * 100",
            "Inflation-Adjusted Return": "((1 + nominal_return) / (1 + inflation_rate) - 1) * 100",
            "Bond Pricing": "self.bond_pricing(face_value, coupon_rate, market_rate, years_to_maturity)",
            "Dividend Yield": "(annual_dividend / stock_price) * 100"
        }
        self.selected_template = tk.StringVar(self.parent)
    
    def create_template_widgets(self):
        # Template selection Drop-down menu
        self.template_frame = tk.Frame(self.parent)
        self.template_frame.grid(row=0, column=4, rowspan=6, padx=20, pady=20, sticky="nswe")

        tk.Label(self.template_frame, text="Templates", font=("Arial", 18)).pack(anchor='w')

        # Notepad and Entry for Templates
        self.notepad = Text(self.template_frame, font=("Arial", 14), height=15, width=35, wrap="word", bg="white", fg="black", borderwidth=2, relief="solid")
        self.notepad.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        self.entry_bar = tk.Entry(self.template_frame, font=("Arial", 18), borderwidth=2, relief="solid")
        self.entry_bar.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Button(self.template_frame, text="Enter", font=("Arial", 18), command=self.calculate_template).pack(pady=10)

    def on_template_select(self, selected_template):
        if selected_template:
            template_expression = self.templates[selected_template]
            self.display_template(template_expression)
    
    def display_template(self, expression):
        self.notepad.delete(1.0, tk.END)
        self.notepad.insert(tk.END, f"Template: {expression}\n")
        self.entry_bar.delete(0, tk.END)
        self.entry_bar.insert(0, "Enter values here separated by commas (e.g., 1000, 'USD', 'EUR')")

    def calculate_template(self):
        selected_template = self.selected_template.get()
        if selected_template and selected_template != "Select Template":
            template_expression = self.templates[selected_template]
            try:
                # Handle special cases for financial calculations
                if selected_template == "Currency Conversion":
                    inputs = self.entry_bar.get().split(',')
                    result = self.currency_conversion(float(inputs[0]), inputs[1].strip(), inputs[2].strip())
                elif selected_template == "Loan Amortization":
                    inputs = list(map(float, self.entry_bar.get().split(',')))
                    result = self.loan_amortization(*inputs)
                elif selected_template == "Monthly Mortgage Payment":
                    inputs = list(map(float, self.entry_bar.get().split(',')))
                    result = self.mortgage_payment(*inputs)
                elif selected_template == "Retirement Savings Estimate":
                    inputs = list(map(float, self.entry_bar.get().split(',')))
                    result = self.retirement_savings(*inputs)
                elif selected_template == "APR Calculation":
                    inputs = list(map(float, self.entry_bar.get().split(',')))
                    result = self.apr(*inputs)
                elif selected_template == "Bond Pricing":
                    inputs = list(map(float, self.entry_bar.get().split(',')))
                    result = self.bond_pricing(*inputs)
                else:
                    input_values = list(map(float, self.entry_bar.get().split(',')))
                    result = eval(template_expression, {}, dict(zip(self.templates.keys(), input_values)))
                messagebox.showinfo("Result", f"Result: {result}")
            except Exception as e:
                messagebox.showerror("Error", f"Error in calculation: {e}")
        else:
            messagebox.showerror("Error", "Please select a template.")
    
    # Financial calculation methods
    def currency_conversion(self, amount, from_currency, to_currency):
        if from_currency in self.currency_rates and to_currency in self.currency_rates:
            conversion_rate = self.currency_rates[to_currency] / self.currency_rates[from_currency]
            return amount * conversion_rate
        else:
            return "Error: Currency not supported."

    def loan_amortization(self, principal, rate, time):
        monthly_rate = rate / 12 / 100
        num_payments = time * 12
        if monthly_rate == 0:
            return principal / num_payments
        else:
            return (principal * monthly_rate) / (1 - (1 + monthly_rate) ** -num_payments)
    
    def mortgage_payment(self, principal, rate, time):
        monthly_rate = rate / 12 / 100
        num_payments = time * 12
        if monthly_rate == 0:
            return principal / num_payments
        else:
            return (principal * monthly_rate) / (1 - (1 + monthly_rate) ** -num_payments)

    def retirement_savings(self, current_savings, annual_contribution, years, rate):
        total_savings = current_savings
        for year in range(int(years)):
            total_savings += annual_contribution
            total_savings *= (1 + rate / 100)
        return total_savings

    def apr(self, principal, interest, time):
        return (interest / principal) / time * 100
    
    def bond_pricing(self, face_value, coupon_rate, market_rate, years_to_maturity):
        annual_coupon = face_value * coupon_rate / 100
        present_value = sum([annual_coupon / (1 + market_rate / 100) ** i for i in range(1, int(years_to_maturity) + 1)])
        present_value += face_value / (1 + market_rate / 100) ** years_to_maturity
        return present_value

    def convert_currency(self, from_currency):
        self.notepad.delete(1.0, tk.END)
        self.notepad.insert(tk.END, f"Convert {from_currency} to another currency\n")
        self.entry_bar.delete(0, tk.END)
        self.entry_bar.insert(0, f"Enter amount to convert from {from_currency}")

if __name__ == "__main__":
    app = MoneyCalculator()
    app.mainloop()
